const ipData = require("./ipdata");

module.exports = {
  ipdata: ipData
};
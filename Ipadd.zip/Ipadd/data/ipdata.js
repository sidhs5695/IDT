const collections = require('../db/collections');
const ipdata = collections.ipdata;
const mongodb = require("mongodb");
const axios = require("axios");

let exportedMethods = {

    async getSearchData(ipadd) {
        const {data} = await axios.get(`https://ipapi.co/${ipadd}/json`);
        return data;
    },

    async getAllData() {
        const ipdataCollection = await ipdata();
        const searchList = await ipdataCollection.find({}).toArray();
        if (!searchList) throw 'No data available!';
        return searchList;
    },

    async getNData(n) {
        const ipdataCollection = await ipdata();
        let count = await ipdataCollection.count();
        let num = count-n;
        if(num<0)
        {
            num=0;
        }
        const searchList = await ipdataCollection.find().skip(num).toArray();
        let tempArr = [];
        for(let i=0,j=searchList.length-1;i<searchList.length;i++,j--)
        {
            tempArr[i]=searchList[j];
        }
        if (!searchList) throw 'No data available!';
        return tempArr;
    },

    async getCountryData(country) {
        const ipdataCollection = await ipdata();
        
        const searchList = await ipdataCollection.find( { country: country } ).toArray();
        let tempArr = [];
        for(let i=0,j=searchList.length-1;i<searchList.length;i++,j--)
        {
            tempArr[i]=searchList[j];
        }
        if (!searchList) throw 'No data available!';
        return tempArr;
    },

    async getIpDatabyId(id) {

    if(typeof id === "undefined")
    {
        throw "Input cannot be empty!";
    }
    else if(id instanceof Array)
    {
        throw "Input cannot be type of an array!";
    }
    else if(id.length<12)
    {
        throw "ID should be single string of 12 bytes or 24 hex characters only!";
    }
    else
    {
        const ipdataCollection = await ipdata();
        const entry = await ipdataCollection.findOne({ _id: mongodb.ObjectID(id) });
        
        if (!entry)
        {
            throw `No entry found in database with the id : ${id}`;
        }
        else 
        {
            return entry;
        }   
    }
    
    },

    async addSearchData(ipadd, reg, cont, long, lat) {

        if(!ipadd)
        {
            throw "Input cannot be empty!";
        }
        else if(typeof ipadd === "undefined")
        {
            throw "IP Adress cannot be empty!";
        }
        else if(ipadd instanceof Array)
        {
            throw "Input cannot be type of an array!";
        }
        else if(typeof ipadd != "string")
        {
            throw "Invalid IP Address Format!";
        }
        else
        {
            const ipdataCollection = await ipdata();
            const searchData = await this.getSearchData(ipadd);
            var d = new Date();
            var yr = d.getFullYear();
            var mo = d.getMonth()+1;
            var day= d.getDate();
            var todayDate = yr+"-"+mo+"-"+day;

            const newEntry = {
            address: ipadd,
            region: searchData.region,
            country: searchData.country_name,
            date: todayDate,
            longitude: searchData.longitude,
            latitude: searchData.latitude
        };
      
          const newInsertInformation = await ipdataCollection.insertOne(newEntry);
          if (newInsertInformation.insertedCount === 0) throw 'Insert failed!';
          return await this.getIpDatabyId(newInsertInformation.insertedId);
        }
    
      }
};

module.exports = exportedMethods;
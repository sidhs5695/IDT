const iplocRoutes = require("./iploc");

const constructorMethod = app => {
  app.use("/", iplocRoutes);

};

module.exports = constructorMethod;
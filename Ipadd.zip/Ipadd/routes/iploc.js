const express = require("express");
const router = express.Router();
const data = require("../data");
const searchData = data.ipdata;

router.get("/", (req, res) => {
  res.render("display/index", {keywords: "Location Finder"});
});



router.post("/getlocation", async (req, res) => {
    let postData = req.body;
    let searchValue = postData.ipadd;

    if (!postData.ipadd) {
        res.status(400).render("display/index", { errorMessage: "No data entered!", hasErrors:true });
        return;
        
    }


        const searchList = await searchData.getSearchData(searchValue);
        if(searchList.error)
        {
        res.status(404).render("display/index", { errorMessage: `${searchValue} is not a valid ip! Please Enter Valid IP`, hasErrors:true });
        }
        else
        {
            const searchEntry = await searchData.addSearchData(searchValue);
        res.render("display/index", { searchRes: searchList, keywords: "Location Finder"});
        }

    });

    router.get("/searchhistory", async (req, res) => {
        let searchop = await searchData.getAllData();
        let dataArr = [];
        for(let i=0,j=searchop.length-1;i<searchop.length;i++,j--)
        {
            dataArr[i]=searchop[j];
        }
        let empty ="*hello*";
        let testVar = searchop+"*hello*";
        if(empty===testVar)
        {
            res.status(404).render("display/searchhistory", { errorMessage: "No data available!", keywords: "Location History", hasErrors:true });
        }
        else
        {
            var d = new Date();
            var yr = d.getFullYear();
            var mo = d.getMonth()+1;
            
            if(mo<10)
            {
                mo="0"+mo;
            }

            let minDate = searchop[0].date;
            let strArr = minDate.split("-");
            if(strArr[1]<10)
            {
                strArr[1]="0"+strArr[1];
            }
            minDate=strArr.join("-");
            var day= d.getDate();
            var todayDate = yr+"-"+mo+"-"+day;
            res.render("display/searchhistory", { searchRes: dataArr, length: dataArr.length, dateMax: todayDate, dateMin: minDate, keywords: "Location History", hasErrors:false });
        }
      });

      router.post("/rowfilter", async (req, res) => {
        let postData = req.body;
        let searchValue = postData.rows;
    
        // if (!postData.rows) {
        //     res.status(400).render("display/searchhistory", { errorMessage: "Number of rows cannot be empty!", hasErrors:true });
        //     return;
            
        // }
            const searchList = await searchData.getNData(searchValue);
            res.render("display/searchhistory", { searchRes: searchList, keywords: "Location History", hasErrors:false });
    
        });

        router.post("/countryfilter", async (req, res) => {
            let postData = req.body;
            let country_name = postData.country;
        
            
                const searchList = await searchData.getCountryData(country_name);
                let empty ="*hello*";
                let testVar = searchList+"*hello*";
                if(empty===testVar)
                {
                    res.render("display/searchhistory", { errorMessage: "No data available!", keywords: "Location History", hasErrors:true });
                }
                res.render("display/searchhistory", { searchRes: searchList, keywords: "Location History", hasErrors:false });
        
            });
    

    module.exports = router;